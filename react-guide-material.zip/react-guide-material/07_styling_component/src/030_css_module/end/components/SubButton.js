import styles from "./SubButton.module.css";

const SubButton = () => {
    return <button className={styles.btn}>サブボタン</button>
}

export default SubButton;