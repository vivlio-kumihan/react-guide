import "./SubButton.css";

const SubButton = () => {
    return <button className="btn">サブボタン</button>

}
export default SubButton;