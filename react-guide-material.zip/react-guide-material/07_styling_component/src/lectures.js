/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  '010_inline_style',
  '020_import_css',
  '030_css_module',
  '040_css_in_js',
  '045_practice_css_in_js',
  '050_chakra_ui',
];

export default lectures;
