/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  "010_list_components",
  "020_list_and_key",
  "024_why_key_unique",
  "030_practice_list",
  "040_list_and_filter",
  "050_practice_filter",
  "060_conditional_render",
  "070_refactor_components",
  "080_input_textarea",
  "090_radio",
  "100_single_checkbox",
  "110_multi_checkbox",
  "120_select",
  "130_reminder",
];

export default lectures;
