import "./Profile.css";

const Profile = (props) => {
  return (
    <div className="profile">

    </div>
  );
};


export default Profile;
