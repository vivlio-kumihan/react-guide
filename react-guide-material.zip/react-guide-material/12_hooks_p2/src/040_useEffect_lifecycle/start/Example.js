const Example = () => {
  return (
    <h3>useEffectの呼ばれるタイミングをコンソールで確認してみよう</h3>
  );
};

export default Example;
