/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  "010_useState_to_useReducer",
  "020_useReducer_pros",
  "025_practice_useReducer",
  "030_useContext",
  "040_useContext_with_state",
  "050_context_file",
  "060_context_file_render",
  "065_useContext_with_reducer",
  "070_practice_useContext",
  "080_practice_reminder",
];

export default lectures;
