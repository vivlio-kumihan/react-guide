import Child from "./components/Child";

const Example = () => {
  const value = 'hello'
  return <Child value={value}/>;
};

export default Example;
