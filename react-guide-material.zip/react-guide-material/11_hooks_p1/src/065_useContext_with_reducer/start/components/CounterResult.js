const CounterResult = ({ state }) => {
  return <h3>{state}</h3>;
};

export default CounterResult;