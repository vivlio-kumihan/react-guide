const Example = () => {
  const numArray = [1, 2, 3, 4, 5];

  return (
    <>
      
    </>
  );
};

export default Example;
